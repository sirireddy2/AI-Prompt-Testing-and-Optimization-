"""Pydantic schemas used to validate incoming API requests.

Responses are returned as plain dicts, which FastAPI serialises to JSON
(including timezone-aware datetimes -> ISO strings).
"""
from typing import Optional

from pydantic import BaseModel, Field


class TestPromptRequest(BaseModel):
    """Body of POST /api/test-prompt."""

    original_prompt: str = Field(..., min_length=1, description="The prompt to test.")
    test_input: str = Field(default="", description="Optional input the prompt is applied to.")
    model: Optional[str] = Field(default=None, description="Override the Gemini model.")


class OptimizePromptRequest(BaseModel):
    """Body of POST /api/optimize-prompt."""

    original_prompt: str = Field(..., min_length=1, description="The prompt to improve.")
    test_input: str = Field(default="", description="Optional input the prompt is applied to.")
    test_id: Optional[int] = Field(
        default=None,
        description="Link this optimisation to an existing test (from the Testing page).",
    )
    model: Optional[str] = Field(default=None, description="Override the Gemini model.")


class CompareRequest(BaseModel):
    """Body of POST /api/compare-prompts."""

    original_prompt: str = Field(..., min_length=1)
    optimized_prompt: str = Field(..., min_length=1)
    test_input: str = Field(default="")
    model: Optional[str] = Field(default=None)
    original_test_id: Optional[int] = Field(default=None, description="Reuse this test if it matches.")
    optimized_id: Optional[int] = Field(default=None, description="Reuse this optimised prompt if it matches.")
