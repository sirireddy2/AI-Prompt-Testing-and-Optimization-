"""Application configuration loaded from environment variables.

Values are read from ``backend/.env`` (see ``.env.example``). The Gemini
API key is never hard-coded and never exposed to the frontend.
"""
import os

from dotenv import load_dotenv

# backend/ directory (one level up from app/).
_BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Always load the backend .env file, regardless of the current working dir.
load_dotenv(os.path.join(_BASE_DIR, ".env"))

GEMINI_API_KEY = (os.getenv("GEMINI_API_KEY") or "").strip()
GEMINI_MODEL = (os.getenv("GEMINI_MODEL") or "gemini-1.5-flash").strip()
