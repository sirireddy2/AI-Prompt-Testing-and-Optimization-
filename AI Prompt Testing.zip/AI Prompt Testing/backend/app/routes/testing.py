"""POST /api/test-prompt - run a prompt, evaluate it and save the result."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import PromptTest
from ..schemas import TestPromptRequest
from ..services import evaluation_service, gemini_service
from ..services.gemini_service import GeminiCallError, GeminiConfigError

router = APIRouter()


def scores_from_test(t: PromptTest) -> dict:
    """Build the per-criterion scores dict from a saved PromptTest."""
    return {
        "relevance": t.relevance_score,
        "clarity": t.clarity_score,
        "completeness": t.completeness_score,
        "instruction": t.instruction_score,
        "format": t.format_score,
    }


@router.post("/api/test-prompt")
def test_prompt(payload: TestPromptRequest, db: Session = Depends(get_db)):
    """Generate a response with Gemini, evaluate it, save it and return it."""
    if not payload.original_prompt.strip():
        raise HTTPException(status_code=400, detail="Original prompt cannot be empty.")

    try:
        response_text = gemini_service.generate_response(
            payload.original_prompt, payload.test_input, payload.model
        )
        scores, overall, reasoning = evaluation_service.evaluate(
            payload.original_prompt, payload.test_input, response_text, payload.model
        )
    except GeminiConfigError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except GeminiCallError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=500, detail=f"Unexpected error while testing the prompt: {exc}")

    test = PromptTest(
        original_prompt=payload.original_prompt,
        test_input=payload.test_input,
        original_response=response_text,
        original_score=overall,
        relevance_score=scores["relevance"],
        clarity_score=scores["clarity"],
        completeness_score=scores["completeness"],
        instruction_score=scores["instruction"],
        format_score=scores["format"],
    )
    db.add(test)
    db.commit()
    db.refresh(test)

    return {
        "id": test.id,
        "original_prompt": test.original_prompt,
        "test_input": test.test_input,
        "response": test.original_response,
        "overall_score": test.original_score,
        "scores": scores_from_test(test),
        "reasoning": reasoning,
        "created_at": test.created_at,
    }
