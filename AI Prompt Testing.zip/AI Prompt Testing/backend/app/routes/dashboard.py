"""GET /api/dashboard - aggregated statistics, all from the database."""
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import OptimizedPrompt, PromptTest

router = APIRouter()


def _build_chart(db: Session) -> list:
    """Tests per day for the last 7 days with the average score per day."""
    since = datetime.now(timezone.utc) - timedelta(days=6)
    rows = db.query(PromptTest).filter(PromptTest.created_at >= since).all()

    buckets = {}
    today = datetime.now(timezone.utc)
    for i in range(7):
        day = (today - timedelta(days=6 - i)).date()
        buckets[day.isoformat()] = {
            "date": day.isoformat(),
            "label": day.strftime("%a"),
            "count": 0,
            "total_score": 0.0,
            "scored": 0,
        }

    for t in rows:
        if not t.created_at:
            continue
        created = t.created_at
        if created.tzinfo is None:
            created = created.replace(tzinfo=timezone.utc)
        d = created.astimezone(timezone.utc).date()
        key = d.isoformat()
        if key in buckets:
            buckets[key]["count"] += 1
            if t.original_score is not None:
                buckets[key]["total_score"] += t.original_score
                buckets[key]["scored"] += 1

    chart = []
    for b in buckets.values():
        avg = round(b["total_score"] / b["scored"], 1) if b["scored"] else 0.0
        chart.append({"date": b["date"], "label": b["label"], "count": b["count"], "average_score": avg})
    return chart


@router.get("/api/dashboard")
def dashboard(db: Session = Depends(get_db)):
    total_tests = db.query(PromptTest).count()
    total_optimized = db.query(OptimizedPrompt).count()

    avg = (
        db.query(func.avg(PromptTest.original_score))
        .filter(PromptTest.original_score.isnot(None))
        .scalar()
    )
    average_score = round(float(avg), 1) if avg is not None else 0.0

    recent = db.query(PromptTest).order_by(PromptTest.created_at.desc()).limit(5).all()
    recent_activity = [
        {
            "id": t.id,
            "original_prompt": (t.original_prompt or "")[:140],
            "score": t.original_score,
            "has_optimized": len(t.optimized or []) > 0,
            "created_at": t.created_at,
        }
        for t in recent
    ]

    return {
        "total_prompts_tested": total_tests,
        "total_prompts_optimized": total_optimized,
        "average_quality_score": average_score,
        "recent_activity": recent_activity,
        "history_chart": _build_chart(db),
    }
