"""History endpoints: list, detail and delete tests.

GET    /api/history        - list tests with search/filter/sort
GET    /api/history/{id}   - full detail of one test (with its optimisations)
DELETE /api/history/{id}   - delete a test (cascades to its optimisations)
"""
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import OptimizedPrompt, PromptTest

router = APIRouter()


def _latest_optimized(t: PromptTest) -> Optional[OptimizedPrompt]:
    opts = list(t.optimized or [])
    if not opts:
        return None
    opts.sort(
        key=lambda o: o.created_at or datetime.min.replace(tzinfo=timezone.utc),
        reverse=True,
    )
    return opts[0]


def _optimized_summary(o: OptimizedPrompt) -> dict:
    return {
        "id": o.id,
        "optimized_prompt": o.optimized_prompt,
        "optimization_explanation": o.optimization_explanation,
        "optimized_response": o.optimized_response,
        "optimized_score": o.optimized_score,
        "created_at": o.created_at,
    }


def _history_item(t: PromptTest) -> dict:
    latest = _latest_optimized(t)
    return {
        "id": t.id,
        "original_prompt": t.original_prompt,
        "test_input": t.test_input,
        "original_response": t.original_response,
        "original_score": t.original_score,
        "relevance_score": t.relevance_score,
        "clarity_score": t.clarity_score,
        "completeness_score": t.completeness_score,
        "instruction_score": t.instruction_score,
        "format_score": t.format_score,
        "created_at": t.created_at,
        "optimized": _optimized_summary(latest) if latest else None,
    }


@router.get("/api/history")
def list_history(
    q: str = Query("", description="Search original and optimized prompts."),
    min_score: Optional[float] = Query(None, description="Minimum original score."),
    max_score: Optional[float] = Query(None, description="Maximum original score."),
    has_optimized: Optional[bool] = Query(None, description="Filter by whether an optimization exists."),
    sort: str = Query("newest", description="newest | oldest | score_asc | score_desc"),
    db: Session = Depends(get_db),
):
    query = db.query(PromptTest)

    if q:
        like = f"%{q}%"
        query = query.filter(PromptTest.original_prompt.ilike(like))
    if min_score is not None:
        query = query.filter(PromptTest.original_score >= min_score)
    if max_score is not None:
        query = query.filter(PromptTest.original_score <= max_score)
    if has_optimized is True:
        query = query.filter(PromptTest.optimized.any())
    elif has_optimized is False:
        query = query.filter(~PromptTest.optimized.any())

    if sort == "oldest":
        query = query.order_by(PromptTest.created_at.asc())
    elif sort == "score_desc":
        query = query.order_by(PromptTest.original_score.desc().nullslast())
    elif sort == "score_asc":
        query = query.order_by(PromptTest.original_score.asc().nullslast())
    else:
        query = query.order_by(PromptTest.created_at.desc())

    items = query.all()
    return {"items": [_history_item(t) for t in items], "total": len(items)}


@router.get("/api/history/{test_id}")
def history_detail(test_id: int, db: Session = Depends(get_db)):
    test = db.get(PromptTest, test_id)
    if not test:
        raise HTTPException(status_code=404, detail="History item not found.")
    return {
        "id": test.id,
        "original_prompt": test.original_prompt,
        "test_input": test.test_input,
        "original_response": test.original_response,
        "original_score": test.original_score,
        "relevance_score": test.relevance_score,
        "clarity_score": test.clarity_score,
        "completeness_score": test.completeness_score,
        "instruction_score": test.instruction_score,
        "format_score": test.format_score,
        "created_at": test.created_at,
        "optimized": [
            {
                "id": o.id,
                "optimized_prompt": o.optimized_prompt,
                "optimization_explanation": o.optimization_explanation,
                "optimized_response": o.optimized_response,
                "optimized_score": o.optimized_score,
                "optimized_relevance_score": o.optimized_relevance_score,
                "optimized_clarity_score": o.optimized_clarity_score,
                "optimized_completeness_score": o.optimized_completeness_score,
                "optimized_instruction_score": o.optimized_instruction_score,
                "optimized_format_score": o.optimized_format_score,
                "created_at": o.created_at,
            }
            for o in (test.optimized or [])
        ],
    }


@router.delete("/api/history/{test_id}")
def delete_history(test_id: int, db: Session = Depends(get_db)):
    test = db.get(PromptTest, test_id)
    if not test:
        raise HTTPException(status_code=404, detail="History item not found.")
    db.delete(test)  # cascade removes linked OptimizedPrompt rows
    db.commit()
    return {"deleted": test_id}
