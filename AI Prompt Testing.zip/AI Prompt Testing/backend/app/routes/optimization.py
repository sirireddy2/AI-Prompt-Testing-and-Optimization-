"""POST /api/optimize-prompt and POST /api/compare-prompts.

Optimise is the "heavy" endpoint: it makes sure a baseline test exists,
rewrites the prompt, then runs and evaluates the new version so a complete
original + optimised pair is saved (and History is rich).

Compare has a fast path: if both record ids are supplied and already contain
responses that match the submitted prompts, it returns the saved data
without calling Gemini again.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import OptimizedPrompt, PromptTest
from ..schemas import CompareRequest, OptimizePromptRequest
from ..services import evaluation_service, gemini_service, optimization_service
from ..services.gemini_service import GeminiCallError, GeminiConfigError
from .testing import scores_from_test

router = APIRouter()


def opt_scores_from_record(o: OptimizedPrompt) -> dict:
    return {
        "relevance": o.optimized_relevance_score,
        "clarity": o.optimized_clarity_score,
        "completeness": o.optimized_completeness_score,
        "instruction": o.optimized_instruction_score,
        "format": o.optimized_format_score,
    }


@router.post("/api/optimize-prompt")
def optimize_prompt(payload: OptimizePromptRequest, db: Session = Depends(get_db)):
    """Rewrite a prompt, run the new version and persist the full pair."""
    if not payload.original_prompt.strip():
        raise HTTPException(status_code=400, detail="Original prompt cannot be empty.")

    try:
        # 1. Resolve or create the baseline test for the original prompt.
        test = db.get(PromptTest, payload.test_id) if payload.test_id else None
        if test is None:
            orig_response = gemini_service.generate_response(
                payload.original_prompt, payload.test_input, payload.model
            )
            orig_scores, orig_overall, _ = evaluation_service.evaluate(
                payload.original_prompt, payload.test_input, orig_response, payload.model
            )
            test = PromptTest(
                original_prompt=payload.original_prompt,
                test_input=payload.test_input,
                original_response=orig_response,
                original_score=orig_overall,
                relevance_score=orig_scores["relevance"],
                clarity_score=orig_scores["clarity"],
                completeness_score=orig_scores["completeness"],
                instruction_score=orig_scores["instruction"],
                format_score=orig_scores["format"],
            )
            db.add(test)
            db.commit()
            db.refresh(test)
            orig_scores_dict = orig_scores
        else:
            orig_scores_dict = scores_from_test(test)

        # 2. Generate the improved prompt + explanation.
        optimized_prompt, explanation = optimization_service.optimize(
            payload.original_prompt, payload.test_input, payload.model
        )

        # 3. Run the optimised prompt and evaluate it.
        opt_response = gemini_service.generate_response(
            optimized_prompt, payload.test_input, payload.model
        )
        opt_scores, opt_overall, _ = evaluation_service.evaluate(
            optimized_prompt, payload.test_input, opt_response, payload.model
        )

        opt = OptimizedPrompt(
            test_id=test.id,
            optimized_prompt=optimized_prompt,
            optimization_explanation=explanation,
            optimized_response=opt_response,
            optimized_score=opt_overall,
            optimized_relevance_score=opt_scores["relevance"],
            optimized_clarity_score=opt_scores["clarity"],
            optimized_completeness_score=opt_scores["completeness"],
            optimized_instruction_score=opt_scores["instruction"],
            optimized_format_score=opt_scores["format"],
        )
        db.add(opt)
        db.commit()
        db.refresh(opt)

        return {
            "test_id": test.id,
            "optimized_id": opt.id,
            "original_prompt": test.original_prompt,
            "test_input": test.test_input,
            "optimized_prompt": opt.optimized_prompt,
            "explanation": opt.optimization_explanation,
            "original_response": test.original_response,
            "original_score": test.original_score,
            "original_scores": orig_scores_dict,
            "optimized_response": opt.optimized_response,
            "optimized_score": opt.optimized_score,
            "optimized_scores": opt_scores,
            "created_at": opt.created_at,
        }
    except GeminiConfigError as exc:
        db.rollback()
        raise HTTPException(status_code=503, detail=str(exc))
    except GeminiCallError as exc:
        db.rollback()
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:  # noqa: BLE001
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Unexpected error while optimizing the prompt: {exc}")


def _improvement_summary(diff: float, opt_score, orig_score) -> str:
    if diff > 0:
        return (
            f"The optimized prompt scored {diff} points higher than the original "
            f"({opt_score} vs {orig_score}). The changes appear to have improved the response quality."
        )
    if diff < 0:
        return (
            f"The optimized prompt scored {abs(diff)} points lower than the original "
            f"({opt_score} vs {orig_score}). The original prompt may already be strong for this input."
        )
    return f"Both prompts scored equally ({opt_score}). The optimization did not change the estimated quality for this input."


@router.post("/api/compare-prompts")
def compare_prompts(payload: CompareRequest, db: Session = Depends(get_db)):
    """Generate and evaluate both prompts and return a side-by-side comparison."""
    if not payload.original_prompt.strip() or not payload.optimized_prompt.strip():
        raise HTTPException(status_code=400, detail="Both original and optimized prompts are required.")

    try:
        original_test = db.get(PromptTest, payload.original_test_id) if payload.original_test_id else None
        optimized_rec = db.get(OptimizedPrompt, payload.optimized_id) if payload.optimized_id else None

        # Fast path: both records exist, already have responses, and match the
        # submitted prompts -> return saved data without calling Gemini.
        fast = (
            original_test is not None
            and optimized_rec is not None
            and original_test.original_response
            and optimized_rec.optimized_response
            and original_test.original_prompt == payload.original_prompt
            and optimized_rec.optimized_prompt == payload.optimized_prompt
        )

        if fast:
            orig = {
                "prompt": original_test.original_prompt,
                "response": original_test.original_response,
                "overall_score": original_test.original_score,
                "scores": scores_from_test(original_test),
                "reasoning": None,
                "test_id": original_test.id,
            }
            opt = {
                "prompt": optimized_rec.optimized_prompt,
                "response": optimized_rec.optimized_response,
                "overall_score": optimized_rec.optimized_score,
                "scores": opt_scores_from_record(optimized_rec),
                "reasoning": None,
                "optimized_id": optimized_rec.id,
                "test_id": optimized_rec.test_id,
            }
        else:
            # --- Original side ---
            # Reuse the saved response when the prompt matches and already has one;
            # otherwise generate + evaluate and create/fill the record.
            if (
                original_test
                and original_test.original_prompt == payload.original_prompt
                and original_test.original_response
            ):
                orig_test = original_test
            else:
                orig_response = gemini_service.generate_response(
                    payload.original_prompt, payload.test_input, payload.model
                )
                orig_scores, orig_overall, _ = evaluation_service.evaluate(
                    payload.original_prompt, payload.test_input, orig_response, payload.model
                )
                if original_test and original_test.original_prompt == payload.original_prompt:
                    orig_test = original_test  # existed but had no response
                else:
                    orig_test = PromptTest(
                        original_prompt=payload.original_prompt,
                        test_input=payload.test_input,
                    )
                    db.add(orig_test)
                orig_test.original_response = orig_response
                orig_test.original_score = orig_overall
                orig_test.relevance_score = orig_scores["relevance"]
                orig_test.clarity_score = orig_scores["clarity"]
                orig_test.completeness_score = orig_scores["completeness"]
                orig_test.instruction_score = orig_scores["instruction"]
                orig_test.format_score = orig_scores["format"]
                db.commit()
                db.refresh(orig_test)

            orig = {
                "prompt": orig_test.original_prompt,
                "response": orig_test.original_response,
                "overall_score": orig_test.original_score,
                "scores": scores_from_test(orig_test),
                "reasoning": None,
                "test_id": orig_test.id,
            }

            # --- Optimized side (linked to the original test) ---
            if (
                optimized_rec
                and optimized_rec.optimized_prompt == payload.optimized_prompt
                and optimized_rec.optimized_response
            ):
                opt_rec = optimized_rec
                if opt_rec.test_id != orig_test.id:
                    opt_rec.test_id = orig_test.id
                    db.commit()
                    db.refresh(opt_rec)
            else:
                opt_response = gemini_service.generate_response(
                    payload.optimized_prompt, payload.test_input, payload.model
                )
                opt_scores, opt_overall, _ = evaluation_service.evaluate(
                    payload.optimized_prompt, payload.test_input, opt_response, payload.model
                )
                if optimized_rec and optimized_rec.optimized_prompt == payload.optimized_prompt:
                    opt_rec = optimized_rec  # existed but had no response
                else:
                    opt_rec = OptimizedPrompt(
                        test_id=orig_test.id,
                        optimized_prompt=payload.optimized_prompt,
                        optimization_explanation="Generated during comparison",
                    )
                    db.add(opt_rec)
                opt_rec.optimized_response = opt_response
                opt_rec.optimized_score = opt_overall
                opt_rec.optimized_relevance_score = opt_scores["relevance"]
                opt_rec.optimized_clarity_score = opt_scores["clarity"]
                opt_rec.optimized_completeness_score = opt_scores["completeness"]
                opt_rec.optimized_instruction_score = opt_scores["instruction"]
                opt_rec.optimized_format_score = opt_scores["format"]
                opt_rec.test_id = orig_test.id
                db.commit()
                db.refresh(opt_rec)

            opt = {
                "prompt": opt_rec.optimized_prompt,
                "response": opt_rec.optimized_response,
                "overall_score": opt_rec.optimized_score,
                "scores": opt_scores_from_record(opt_rec),
                "reasoning": None,
                "optimized_id": opt_rec.id,
                "test_id": opt_rec.test_id,
            }

        diff = round((opt["overall_score"] or 0) - (orig["overall_score"] or 0), 1)
        return {
            "original": orig,
            "optimized": opt,
            "score_difference": diff,
            "improvement_summary": _improvement_summary(
                diff, opt["overall_score"], orig["overall_score"]
            ),
        }
    except GeminiConfigError as exc:
        db.rollback()
        raise HTTPException(status_code=503, detail=str(exc))
    except GeminiCallError as exc:
        db.rollback()
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:  # noqa: BLE001
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Unexpected error while comparing prompts: {exc}")
