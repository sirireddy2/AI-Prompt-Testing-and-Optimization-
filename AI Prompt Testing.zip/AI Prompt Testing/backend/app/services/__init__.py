"""Service modules that wrap the Gemini API and the scoring logic."""
