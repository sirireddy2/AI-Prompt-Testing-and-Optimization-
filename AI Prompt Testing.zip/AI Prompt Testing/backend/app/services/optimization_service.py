"""Parse Gemini's optimisation JSON into an improved prompt + explanation."""
from __future__ import annotations

import json
import logging
import re
from typing import Tuple

from . import gemini_service

logger = logging.getLogger("promptpilot.optimization")


def _extract_json(text: str) -> dict:
    text = (text or "").strip()
    if not text:
        raise ValueError("Empty response.")
    fence = re.search(r"```(?:json)?\s*(.*?)\s*```", text, re.DOTALL)
    if fence:
        text = fence.group(1).strip()
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end < start:
        raise ValueError("No JSON object found in the response.")
    return json.loads(text[start:end + 1])


def optimize(prompt: str, test_input: str, model_name: str | None = None) -> Tuple[str, str]:
    """Return ``(optimized_prompt, explanation)``.

    Raises ``GeminiCallError`` if the underlying call fails, or ``ValueError``
    if the response could not be parsed into an optimized prompt.
    """
    raw = gemini_service.optimize_prompt(prompt, test_input, model_name)
    data = _extract_json(raw)
    optimized = str(data.get("optimized_prompt") or "").strip()
    explanation = str(data.get("explanation") or "").strip()
    if not optimized:
        raise ValueError("Gemini did not return an optimized prompt.")
    if not explanation:
        explanation = "No explanation was provided."
    return optimized, explanation
