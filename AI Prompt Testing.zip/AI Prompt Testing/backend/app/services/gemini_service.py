"""Gemini API integration.

All access to the Google Generative AI SDK happens here, behind small
functions the rest of the app can call:

    generate_response(prompt, test_input)   -> str            (natural text)
    evaluate_response(...)                    -> str            (JSON-ish text)
    optimize_prompt(...)                      -> str            (JSON-ish text)

SDK errors are translated into ``GeminiConfigError`` / ``GeminiCallError`` so
the routes can map them to clean HTTP responses.
"""
from __future__ import annotations

import logging
from typing import Optional

import google.generativeai as genai

from ..config import GEMINI_API_KEY, GEMINI_MODEL

logger = logging.getLogger("promptpilot.gemini")


class GeminiConfigError(Exception):
    """The Gemini API key is missing or the SDK is not configured."""


class GeminiCallError(Exception):
    """A Gemini API call failed (network, rate limit, bad key/model, safety)."""


_configured = False


def is_configured() -> bool:
    """True when a Gemini API key is present in the environment."""
    return bool(GEMINI_API_KEY)


def _ensure_configured() -> None:
    global _configured
    if not GEMINI_API_KEY:
        raise GeminiConfigError(
            "Gemini API key is not configured. Add GEMINI_API_KEY to backend/.env "
            "and restart the backend server."
        )
    if not _configured:
        genai.configure(api_key=GEMINI_API_KEY)
        _configured = True


def _resolve_model(model_name: Optional[str] = None) -> genai.GenerativeModel:
    _ensure_configured()
    name = (model_name or GEMINI_MODEL or "").strip()
    if not name:
        raise GeminiConfigError("GEMINI_MODEL is not configured.")
    return genai.GenerativeModel(name)


def generate_response(prompt: str, test_input: str, model_name: Optional[str] = None) -> str:
    """Run the user's prompt against the test input and return the AI text."""
    model = _resolve_model(model_name)
    if test_input and test_input.strip():
        instruction = (
            "You are an AI assistant. Carefully follow the instructions in the PROMPT "
            "to process the INPUT and produce exactly the response the prompt asks for.\n\n"
            f"=== PROMPT ===\n{prompt}\n\n=== INPUT ===\n{test_input}\n\n=== RESPONSE ==="
        )
    else:
        instruction = (
            "You are an AI assistant. Carefully follow the instructions in the PROMPT "
            "and produce exactly the response the prompt asks for.\n\n"
            f"=== PROMPT ===\n{prompt}\n\n=== RESPONSE ==="
        )
    try:
        result = model.generate_content(instruction)
    except Exception as exc:  # noqa: BLE001 - translate SDK errors
        raise GeminiCallError(_describe_sdk_error(exc)) from exc
    text = getattr(result, "text", None)
    if not text or not text.strip():
        raise GeminiCallError(
            "Gemini returned an empty response. The request may have been blocked by "
            "safety filters - try rephrasing the prompt."
        )
    return text.strip()


_EVAL_TEMPLATE = """You are a strict but fair evaluator of AI prompt outputs.
You will receive a PROMPT (the instructions), the INPUT it was applied to (may be empty), and the RESPONSE an AI produced.
Score the RESPONSE on five criteria from 0 to 100 using this rubric:

- relevance: Does the response directly address the INPUT and the PROMPT's goal?
- clarity: Is the response clear, well-structured and easy to understand?
- completeness: Does it cover what the prompt asked for without major omissions?
- instruction: Does it follow the PROMPT's specific instructions and constraints (role, tone, length, steps, constraints)?
- format: Does it follow the requested output format (list, JSON, table, headings, etc.)? If no format was requested, judge how appropriate the formatting is.

Return ONLY a JSON object with this exact shape (no extra text):
{{
  "relevance": <0-100>,
  "clarity": <0-100>,
  "completeness": <0-100>,
  "instruction": <0-100>,
  "format": <0-100>,
  "reasoning": "<one or two sentences on the main strengths and weaknesses>"
}}

=== PROMPT ===
{prompt}

=== INPUT ===
{test_input}

=== RESPONSE ===
{response}
"""


def evaluate_response(prompt: str, test_input: str, response: str, model_name: Optional[str] = None) -> str:
    """Ask Gemini to score the response. Returns raw model text (JSON-ish)."""
    model = _resolve_model(model_name)
    body = _EVAL_TEMPLATE.format(
        prompt=prompt,
        test_input=test_input or "(no input provided)",
        response=response,
    )
    try:
        # Structured JSON output gives reliable parsing when the model supports it.
        result = model.generate_content(
            body,
            generation_config=genai.GenerationConfig(response_mime_type="application/json"),
        )
    except Exception as exc:  # noqa: BLE001
        # Some models/configs reject response_mime_type; retry in plain mode.
        logger.warning("JSON-mode eval failed (%s); retrying in plain mode.", exc)
        try:
            result = model.generate_content(body)
        except Exception as exc2:  # noqa: BLE001
            raise GeminiCallError(_describe_sdk_error(exc2)) from exc2
    text = getattr(result, "text", None)
    if not text or not text.strip():
        raise GeminiCallError("Gemini returned an empty evaluation response.")
    return text.strip()


_OPT_TEMPLATE = """You are an expert prompt engineer. Improve the given PROMPT so it produces better, more consistent AI outputs.
Analyze the PROMPT (and the INPUT it is applied to, if any) and produce an improved version.

Goals:
- Add any missing but necessary instructions (role, goal, context, output format, constraints).
- Make the desired output format explicit.
- Remove ambiguity and contradictions.
- Keep it concise; do not bloat it with filler.
- Preserve the user's original intent.

Return ONLY a JSON object with this exact shape (no extra text):
{{
  "optimized_prompt": "<the full improved prompt>",
  "explanation": "<short explanation of the key changes you made and why - a few bullet points or a short paragraph>"
}}

=== ORIGINAL PROMPT ===
{prompt}

=== INPUT IT IS APPLIED TO ===
{test_input}
"""


def optimize_prompt(prompt: str, test_input: str, model_name: Optional[str] = None) -> str:
    """Ask Gemini for an improved prompt. Returns raw model text (JSON-ish)."""
    model = _resolve_model(model_name)
    body = _OPT_TEMPLATE.format(
        prompt=prompt,
        test_input=test_input or "(no input provided)",
    )
    try:
        result = model.generate_content(
            body,
            generation_config=genai.GenerationConfig(response_mime_type="application/json"),
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning("JSON-mode optimize failed (%s); retrying in plain mode.", exc)
        try:
            result = model.generate_content(body)
        except Exception as exc2:  # noqa: BLE001
            raise GeminiCallError(_describe_sdk_error(exc2)) from exc2
    text = getattr(result, "text", None)
    if not text or not text.strip():
        raise GeminiCallError("Gemini returned an empty optimization response.")
    return text.strip()


def _describe_sdk_error(exc: Exception) -> str:
    """Turn a Google SDK exception into a short, user-friendly message."""
    name = type(exc).__name__
    msg = str(exc).lower()
    if "api_key" in msg or "permission" in msg or "unauthenticated" in msg or name == "PermissionDenied":
        return "Invalid or unauthorized Gemini API key."
    if "quota" in msg or "rate" in msg or "resourceexhausted" in name.lower() or "resource_exhausted" in msg:
        return "Gemini rate limit or quota exceeded. Please wait a moment and try again."
    if "not found" in msg or ("model" in msg and ("not" in msg or "unsupported" in msg)):
        return f"The configured model could not be used: {exc}"
    return f"Gemini request failed: {exc}"
