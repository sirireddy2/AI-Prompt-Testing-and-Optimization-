"""Parse Gemini's evaluation JSON into a clean scores dictionary.

If Gemini returns non-JSON (or the call failed upstream and was retried),
we fall back to clearly-labeled neutral estimates instead of crashing, so
the UI can always show something. These are estimates, not verified truth.
"""
from __future__ import annotations

import json
import logging
import re
from typing import Dict, Tuple

from . import gemini_service
from .gemini_service import GeminiCallError

logger = logging.getLogger("promptpilot.evaluation")

# The five rubric criteria, in display order.
CRITERIA = ("relevance", "clarity", "completeness", "instruction", "format")

_FALLBACK_NOTE = (
    "Automatic evaluation could not be parsed, so neutral estimated scores are shown. "
    "These are estimates, not verified correctness."
)


def _extract_json(text: str) -> dict:
    """Best-effort extraction of a JSON object from a model response."""
    text = (text or "").strip()
    if not text:
        raise ValueError("Empty response.")
    # Strip markdown code fences if present.
    fence = re.search(r"```(?:json)?\s*(.*?)\s*```", text, re.DOTALL)
    if fence:
        text = fence.group(1).strip()
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end < start:
        raise ValueError("No JSON object found in the response.")
    return json.loads(text[start:end + 1])


def _clamp(value, default: float = 0.0) -> float:
    try:
        v = float(value)
    except (TypeError, ValueError):
        return float(default)
    if v < 0:
        return 0.0
    if v > 100:
        return 100.0
    return round(v, 1)


def evaluate(
    prompt: str, test_input: str, response: str, model_name: str | None = None
) -> Tuple[Dict[str, float], float, str]:
    """Evaluate a generated response.

    Returns ``(scores_dict, overall_score, reasoning)``.
    API errors propagate as ``GeminiCallError``; parse failures fall back to
    neutral estimated scores so the UI never crashes.
    """
    raw = gemini_service.evaluate_response(prompt, test_input, response, model_name)
    try:
        data = _extract_json(raw)
    except Exception as exc:  # noqa: BLE001 - graceful fallback
        logger.warning("Evaluation parsing failed (%s); using neutral fallback scores.", exc)
        scores = {c: 50.0 for c in CRITERIA}
        return scores, 50.0, _FALLBACK_NOTE

    scores = {c: _clamp(data.get(c)) for c in CRITERIA}
    overall = round(sum(scores.values()) / len(CRITERIA), 1)
    reasoning = str(data.get("reasoning") or "").strip()
    return scores, overall, reasoning
