"""PromptPilot backend package.

A FastAPI application that tests, evaluates and optimises AI prompts
using the Google Gemini API, and persists everything in SQLite.
"""
