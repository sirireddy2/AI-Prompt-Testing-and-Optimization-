"""FastAPI application entry point for PromptPilot.

Run from the backend/ directory with:

    uvicorn app.main:app --reload --port 8000

On startup the SQLite database and all tables are created automatically.
"""
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import GEMINI_MODEL
from .database import init_db
from .routes import dashboard, history, optimization, testing
from .services import gemini_service

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("promptpilot")


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Create the SQLite database + tables automatically on first start.
    init_db()
    db_path = str(__import__("app.database", fromlist=["DB_PATH"]).DB_PATH)
    logger.info("Database ready at %s", db_path)
    yield


app = FastAPI(
    title="PromptPilot API",
    version="1.0.0",
    description="AI Prompt Testing & Optimization Tool",
    lifespan=lifespan,
)

# Allow the Vite dev server (and the production preview) to call the API.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:4173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def root():
    return {"name": "PromptPilot API", "status": "ok"}


@app.get("/api/status")
def status():
    """Frontend uses this to show a configuration banner when the key is missing."""
    return {
        "gemini_configured": gemini_service.is_configured(),
        "model": GEMINI_MODEL,
    }


app.include_router(dashboard.router)
app.include_router(testing.router)
app.include_router(optimization.router)
app.include_router(history.router)
