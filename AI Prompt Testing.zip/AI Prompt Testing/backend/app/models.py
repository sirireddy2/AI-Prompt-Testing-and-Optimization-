"""SQLAlchemy ORM models for PromptPilot.

Two tables, connected with a foreign key:

``prompt_tests``      - one row per prompt that has been tested.
``optimized_prompts`` - one or more improved versions linked to a test.
"""
from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer, Text
from sqlalchemy.orm import relationship

from .database import Base


def _now() -> datetime:
    """Current UTC time (stored timezone-aware)."""
    return datetime.now(timezone.utc)


class PromptTest(Base):
    """A prompt that was run against Gemini and scored."""

    __tablename__ = "prompt_tests"

    id = Column(Integer, primary_key=True, index=True)
    original_prompt = Column(Text, nullable=False)
    test_input = Column(Text, nullable=True, default="")
    original_response = Column(Text, nullable=True)
    original_score = Column(Float, nullable=True)
    relevance_score = Column(Float, nullable=True)
    clarity_score = Column(Float, nullable=True)
    completeness_score = Column(Float, nullable=True)
    instruction_score = Column(Float, nullable=True)
    format_score = Column(Float, nullable=True)
    created_at = Column(DateTime(timezone=True), default=_now)

    # All optimisation attempts made for this test. Deleting a test cascades
    # to its optimised prompts.
    optimized = relationship(
        "OptimizedPrompt",
        back_populates="test",
        cascade="all, delete-orphan",
        order_by="OptimizedPrompt.created_at",
    )


class OptimizedPrompt(Base):
    """An improved version of a prompt, with its own response and score."""

    __tablename__ = "optimized_prompts"

    id = Column(Integer, primary_key=True, index=True)
    test_id = Column(
        Integer,
        ForeignKey("prompt_tests.id", ondelete="CASCADE"),
        nullable=True,
        index=True,
    )
    optimized_prompt = Column(Text, nullable=False)
    optimization_explanation = Column(Text, nullable=True, default="")
    optimized_response = Column(Text, nullable=True)
    optimized_score = Column(Float, nullable=True)
    # Per-criterion breakdown of the optimised response, so a comparison can
    # be shown without re-calling Gemini.
    optimized_relevance_score = Column(Float, nullable=True)
    optimized_clarity_score = Column(Float, nullable=True)
    optimized_completeness_score = Column(Float, nullable=True)
    optimized_instruction_score = Column(Float, nullable=True)
    optimized_format_score = Column(Float, nullable=True)
    created_at = Column(DateTime(timezone=True), default=_now)

    test = relationship("PromptTest", back_populates="optimized")
