"""End-to-end AI flow tests with Gemini MOCKED.

Gemini is monkeypatched so these run offline and never touch the network or a
real API key. They verify the full route -> service -> DB -> response pipeline,
scoring math, and persistence. Live Gemini testing is reported separately as
pending API configuration.
"""
import pytest

from app.models import OptimizedPrompt, PromptTest
from app.services import gemini_service

EXPECTED_OVERALL = round((80 + 70 + 60 + 90 + 50) / 5, 1)  # 70.0

IMPROVED_PROMPT = (
    "You are an expert teacher. Explain the topic clearly for school students in "
    "simple English. Return exactly 3 short bullet points."
)
OPT_EXPLANATION = (
    "- Added an expert role.\n- Added the audience and tone.\n- Added an explicit "
    "output format (3 bullet points)."
)


def _install_mocks(monkeypatch, calls):
    def fake_generate(prompt, test_input, model_name=None):
        calls["generate"] += 1
        return f"[AI RESPONSE] prompt='{prompt[:30]}' input='{(test_input or '')[:20]}'"

    def fake_evaluate(prompt, test_input, response, model_name=None):
        calls["evaluate"] += 1
        return (
            '{"relevance":80,"clarity":70,"completeness":60,"instruction":90,'
            '"format":50,"reasoning":"mock reasoning"}'
        )

    def fake_optimize(prompt, test_input, model_name=None):
        calls["optimize"] += 1
        import json
        return json.dumps({"optimized_prompt": IMPROVED_PROMPT, "explanation": OPT_EXPLANATION})

    monkeypatch.setattr(gemini_service, "generate_response", fake_generate)
    monkeypatch.setattr(gemini_service, "evaluate_response", fake_evaluate)
    monkeypatch.setattr(gemini_service, "optimize_prompt", fake_optimize)
    return calls


@pytest.fixture
def mock_gemini(monkeypatch):
    return _install_mocks(monkeypatch, {"generate": 0, "evaluate": 0, "optimize": 0})


# ---------- Phase 6: Prompt testing ----------

def test_test_prompt_full_flow(client, mock_gemini, db_session):
    r = client.post(
        "/api/test-prompt",
        json={
            "original_prompt": "Explain pollution.",
            "test_input": "Explain air pollution to school students in simple English.",
        },
    )
    assert r.status_code == 200, r.text
    d = r.json()
    # overall is the average of the five criteria
    assert d["overall_score"] == EXPECTED_OVERALL
    for k in ("relevance", "clarity", "completeness", "instruction", "format"):
        assert 0 <= d["scores"][k] <= 100
    assert d["response"].startswith("[AI RESPONSE]")
    # persisted
    rec = db_session.get(PromptTest, d["id"])
    assert rec is not None
    assert rec.original_response.startswith("[AI RESPONSE]")
    assert rec.original_score == EXPECTED_OVERALL
    assert mock_gemini["generate"] == 1 and mock_gemini["evaluate"] == 1


# ---------- Phase 7: Optimization ----------

def test_optimize_full_flow(client, mock_gemini, db_session):
    r = client.post("/api/optimize-prompt", json={"original_prompt": "Write something about technology."})
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["test_id"] and d["optimized_id"]
    # meaningful, clear improved prompt
    assert "expert teacher" in d["optimized_prompt"]
    assert "bullet" in d["optimized_prompt"]
    assert d["explanation"]
    # both original and optimized were run + scored
    assert d["original_score"] == EXPECTED_OVERALL
    assert d["optimized_score"] == EXPECTED_OVERALL
    # persisted and linked
    test = db_session.get(PromptTest, d["test_id"])
    opt = db_session.get(OptimizedPrompt, d["optimized_id"])
    assert test is not None and opt is not None
    assert opt.test_id == test.id
    assert opt.optimized_response.startswith("[AI RESPONSE]")
    # optimize ran: original response + optimized response + optimized prompt
    assert mock_gemini["generate"] == 2
    assert mock_gemini["evaluate"] == 2
    assert mock_gemini["optimize"] == 1


# ---------- Phase 8: Comparison ----------

def test_compare_generate_path(client, mock_gemini, db_session):
    r = client.post(
        "/api/compare-prompts",
        json={
            "original_prompt": "Explain pollution.",
            "optimized_prompt": IMPROVED_PROMPT,
            "test_input": "Explain air pollution to school students in simple English.",
        },
    )
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["original"]["prompt"] == "Explain pollution."
    assert d["optimized"]["prompt"] == IMPROVED_PROMPT
    assert d["original"]["overall_score"] == EXPECTED_OVERALL
    assert d["optimized"]["overall_score"] == EXPECTED_OVERALL
    assert d["score_difference"] == 0.0
    assert "improvement_summary" in d
    # both persisted and linked
    tid, oid = d["original"]["test_id"], d["optimized"]["optimized_id"]
    opt = db_session.get(OptimizedPrompt, oid)
    assert opt is not None and opt.test_id == tid
    # generated both -> 2 generate calls, 2 evaluate calls
    assert mock_gemini["generate"] == 2 and mock_gemini["evaluate"] == 2


def test_compare_fast_path_reuses_records(client, mock_gemini):
    # optimize creates a complete original + optimized pair
    opt = client.post("/api/optimize-prompt", json={"original_prompt": "Write something about technology.", "test_input": ""})
    assert opt.status_code == 200
    od = opt.json()
    baseline = dict(mock_gemini)

    # compare with matching ids -> should NOT call Gemini again
    r = client.post(
        "/api/compare-prompts",
        json={
            "original_prompt": od["original_prompt"],
            "optimized_prompt": od["optimized_prompt"],
            "test_input": "",
            "original_test_id": od["test_id"],
            "optimized_id": od["optimized_id"],
        },
    )
    assert r.status_code == 200, r.text
    d = r.json()
    assert mock_gemini["generate"] == baseline["generate"], "fast path must not call generate_response"
    assert mock_gemini["evaluate"] == baseline["evaluate"], "fast path must not call evaluate_response"
    assert d["original"]["test_id"] == od["test_id"]
    assert d["optimized"]["optimized_id"] == od["optimized_id"]


def test_compare_fast_path_not_used_when_prompt_changed(client, mock_gemini):
    opt = client.post("/api/optimize-prompt", json={"original_prompt": "Write something about technology.", "test_input": ""})
    od = opt.json()
    baseline = dict(mock_gemini)
    # change the optimized prompt -> must regenerate
    r = client.post(
        "/api/compare-prompts",
        json={
            "original_prompt": od["original_prompt"],
            "optimized_prompt": "Edited optimized prompt that differs from saved.",
            "test_input": "",
            "original_test_id": od["test_id"],
            "optimized_id": od["optimized_id"],
        },
    )
    assert r.status_code == 200, r.text
    # original reused (matches) so only optimized regenerated -> +1 generate, +1 evaluate
    assert mock_gemini["generate"] == baseline["generate"] + 1
    assert mock_gemini["evaluate"] == baseline["evaluate"] + 1


# ---------- Dashboard + history integration ----------

def test_dashboard_and_history_reflect_data(client, mock_gemini):
    client.post("/api/test-prompt", json={"original_prompt": "Explain pollution to students", "test_input": ""})
    client.post("/api/test-prompt", json={"original_prompt": "Write a poem about rain", "test_input": ""})

    d = client.get("/api/dashboard").json()
    assert d["total_prompts_tested"] == 2
    assert d["average_quality_score"] == EXPECTED_OVERALL
    assert len(d["recent_activity"]) == 2

    h = client.get("/api/history").json()
    assert h["total"] == 2
    assert all(i["original_score"] == EXPECTED_OVERALL for i in h["items"])


def test_history_search_filter_and_delete(client, mock_gemini):
    client.post("/api/test-prompt", json={"original_prompt": "Explain pollution to students", "test_input": ""})
    client.post("/api/test-prompt", json={"original_prompt": "Write a poem about rain", "test_input": ""})

    # search
    assert client.get("/api/history", params={"q": "pollution"}).json()["total"] == 1
    assert client.get("/api/history", params={"q": "poem"}).json()["total"] == 1

    # score filter (mocked eval = 70)
    assert client.get("/api/history", params={"min_score": 80}).json()["total"] == 0
    assert client.get("/api/history", params={"min_score": 60}).json()["total"] == 2

    # optimized-only filter (none optimized yet)
    assert client.get("/api/history", params={"has_optimized": "true"}).json()["total"] == 0

    # sort by score
    items = client.get("/api/history", params={"sort": "score_desc"}).json()["items"]
    assert len(items) == 2

    # view detail
    first_id = items[0]["id"]
    detail = client.get(f"/api/history/{first_id}").json()
    assert detail["id"] == first_id
    assert detail["original_prompt"]

    # delete one
    poem_id = next(i["id"] for i in client.get("/api/history").json()["items"] if "poem" in i["original_prompt"])
    dr = client.delete(f"/api/history/{poem_id}")
    assert dr.status_code == 200
    assert dr.json()["deleted"] == poem_id
    assert client.get("/api/history").json()["total"] == 1
    # deleted record gone
    assert client.get(f"/api/history/{poem_id}").status_code == 404
