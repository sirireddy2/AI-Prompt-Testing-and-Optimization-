"""API endpoint tests: status codes, JSON shape, validation, errors, CORS.

These do NOT call Gemini. The no-key tests force the config-missing path; the
mocked AI flows are in test_ai_flows.py.
"""
from app.services import gemini_service


def test_status(client):
    r = client.get("/api/status")
    assert r.status_code == 200
    d = r.json()
    assert isinstance(d["gemini_configured"], bool)
    assert isinstance(d["model"], str) and d["model"]


def test_dashboard_empty(client):
    r = client.get("/api/dashboard")
    assert r.status_code == 200
    d = r.json()
    assert d["total_prompts_tested"] == 0
    assert d["total_prompts_optimized"] == 0
    assert d["average_quality_score"] == 0.0
    assert d["recent_activity"] == []
    assert len(d["history_chart"]) == 7
    assert all(set(b) == {"date", "label", "count", "average_score"} for b in d["history_chart"])


def test_history_empty(client):
    r = client.get("/api/history")
    assert r.status_code == 200
    d = r.json()
    assert d["items"] == []
    assert d["total"] == 0


def test_history_detail_not_found(client):
    r = client.get("/api/history/9999")
    assert r.status_code == 404
    assert "not found" in r.json()["detail"].lower()


def test_delete_not_found(client):
    r = client.delete("/api/history/9999")
    assert r.status_code == 404


def test_test_prompt_empty_string_rejected(client):
    # empty string fails Pydantic min_length=1 -> 422
    r = client.post("/api/test-prompt", json={"original_prompt": "", "test_input": ""})
    assert r.status_code == 422


def test_test_prompt_whitespace_rejected(client):
    # whitespace passes Pydantic but the route rejects it -> 400
    r = client.post("/api/test-prompt", json={"original_prompt": "   ", "test_input": ""})
    assert r.status_code == 400
    assert "empty" in r.json()["detail"].lower()


def test_test_prompt_no_key_returns_503(client, monkeypatch):
    monkeypatch.setattr(gemini_service, "GEMINI_API_KEY", "")
    monkeypatch.setattr(gemini_service, "_configured", False)
    r = client.post(
        "/api/test-prompt",
        json={"original_prompt": "Explain pollution.", "test_input": "Explain air pollution to school students in simple English."},
    )
    assert r.status_code == 503
    assert "configured" in r.json()["detail"].lower()


def test_optimize_no_key_returns_503(client, monkeypatch):
    monkeypatch.setattr(gemini_service, "GEMINI_API_KEY", "")
    monkeypatch.setattr(gemini_service, "_configured", False)
    r = client.post("/api/optimize-prompt", json={"original_prompt": "Write something about technology."})
    assert r.status_code == 503


def test_compare_missing_optimized_rejected(client):
    r = client.post("/api/compare-prompts", json={"original_prompt": "a"})
    assert r.status_code == 422


def test_compare_whitespace_rejected(client):
    r = client.post("/api/compare-prompts", json={"original_prompt": "a", "optimized_prompt": "   "})
    assert r.status_code == 400


def test_cors_preflight(client):
    r = client.options(
        "/api/test-prompt",
        headers={
            "Origin": "http://localhost:5173",
            "Access-Control-Request-Method": "POST",
            "Access-Control-Request-Headers": "content-type",
        },
    )
    assert r.status_code == 200
    assert r.headers["access-control-allow-origin"] == "http://localhost:5173"
    assert "POST" in r.headers["access-control-allow-methods"]
    assert "content-type" in r.headers["access-control-allow-headers"].lower()


def test_cors_allowed_origin_on_get(client):
    r = client.get("/api/status", headers={"Origin": "http://localhost:5173"})
    assert r.headers["access-control-allow-origin"] == "http://localhost:5173"
