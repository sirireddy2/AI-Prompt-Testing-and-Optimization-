"""Shared pytest fixtures.

The tests use an in-memory SQLite database (with a single shared connection via
StaticPool) so they NEVER touch the real backend/promptpilot.db or its existing
records. The FastAPI get_db dependency is overridden to use this temp DB.
"""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

import app.models  # noqa: F401  register tables on Base.metadata
from app.database import Base, get_db
from app.main import app


@pytest.fixture
def temp_engine():
    """Create a fresh in-memory SQLite DB, create all tables, override get_db."""
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(bind=engine)
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

    def override_get_db():
        db = SessionLocal()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[get_db] = override_get_db
    result = {"engine": engine, "SessionLocal": SessionLocal}
    yield result
    app.dependency_overrides.pop(get_db, None)
    Base.metadata.drop_all(bind=engine)


@pytest.fixture
def client(temp_engine):
    """API test client backed by the temp DB."""
    return TestClient(app)


@pytest.fixture
def db_session(temp_engine):
    """A direct ORM session on the temp DB (same engine as the client)."""
    s = temp_engine["SessionLocal"]()
    try:
        yield s
    finally:
        s.close()
