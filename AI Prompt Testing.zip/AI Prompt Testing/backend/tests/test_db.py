"""Direct ORM/database tests on the temp DB.

Verifies tables, primary keys, foreign key + cascade delete, and persistence
across sessions. The real promptpilot.db is never touched.
"""
from app.models import OptimizedPrompt, PromptTest


def test_tables_exist(temp_engine):
    from sqlalchemy import inspect

    tables = set(inspect(temp_engine["engine"]).get_table_names())
    assert {"prompt_tests", "optimized_prompts"}.issubset(tables)


def test_prompt_test_columns(temp_engine):
    from sqlalchemy import inspect

    cols = {c["name"] for c in inspect(temp_engine["engine"]).get_columns("prompt_tests")}
    required = {
        "id", "original_prompt", "test_input", "original_response", "original_score",
        "relevance_score", "clarity_score", "completeness_score",
        "instruction_score", "format_score", "created_at",
    }
    assert required.issubset(cols)


def test_optimized_columns_and_fk(temp_engine):
    from sqlalchemy import inspect

    insp = inspect(temp_engine["engine"])
    cols = {c["name"] for c in insp.get_columns("optimized_prompts")}
    required = {
        "id", "test_id", "optimized_prompt", "optimization_explanation",
        "optimized_response", "optimized_score",
        "optimized_relevance_score", "optimized_clarity_score",
        "optimized_completeness_score", "optimized_instruction_score",
        "optimized_format_score", "created_at",
    }
    assert required.issubset(cols)

    fks = insp.get_foreign_keys("optimized_prompts")
    assert any(
        fk["referred_table"] == "prompt_tests" and fk["constrained_columns"] == ["test_id"]
        for fk in fks
    ), fks


def _make_test():
    return PromptTest(
        original_prompt="Test prompt",
        test_input="in",
        original_response="resp",
        original_score=70.0,
        relevance_score=80, clarity_score=70, completeness_score=60,
        instruction_score=90, format_score=50,
    )


def test_insert_read_update_delete_and_persistence(temp_engine):
    SL = temp_engine["SessionLocal"]

    # INSERT
    s = SL()
    t = _make_test()
    s.add(t)
    s.commit()
    s.refresh(t)
    test_id = t.id
    s.close()
    assert test_id is not None

    # READ in a new session (persistence across sessions)
    s2 = SL()
    got = s2.get(PromptTest, test_id)
    assert got is not None
    assert got.original_prompt == "Test prompt"
    assert got.original_score == 70.0

    # UPDATE
    got.original_response = "updated response"
    got.original_score = 85.0
    s2.commit()
    s2.close()

    # verify UPDATE persisted
    s3 = SL()
    again = s3.get(PromptTest, test_id)
    assert again.original_response == "updated response"
    assert again.original_score == 85.0

    # INSERT optimized with FK
    o = OptimizedPrompt(
        test_id=again.id,
        optimized_prompt="improved prompt",
        optimization_explanation="explanation",
        optimized_response="optresp",
        optimized_score=90.0,
        optimized_relevance_score=90, optimized_clarity_score=90,
        optimized_completeness_score=90, optimized_instruction_score=90,
        optimized_format_score=90,
    )
    s3.add(o)
    s3.commit()
    s3.refresh(o)
    opt_id = o.id
    assert opt_id is not None and o.test_id == test_id
    s3.close()

    # DELETE test -> cascade should remove the optimized row
    s4 = SL()
    s4.delete(s4.get(PromptTest, test_id))
    s4.commit()
    s4.close()

    s5 = SL()
    assert s5.get(PromptTest, test_id) is None
    assert s5.get(OptimizedPrompt, opt_id) is None  # cascade delete worked
    s5.close()
