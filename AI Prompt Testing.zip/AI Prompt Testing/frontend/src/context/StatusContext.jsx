import { createContext, useContext, useEffect, useState } from "react";
import { api } from "../services/api";

// Provides { configured, model } once on app load so the sidebar/banner
// can tell the user whether Gemini is configured.
const StatusContext = createContext({ configured: null, model: "" });

export const useStatus = () => useContext(StatusContext);

export function StatusProvider({ children }) {
  const [status, setStatus] = useState({ configured: null, model: "" });

  useEffect(() => {
    let active = true;
    api
      .status()
      .then((s) => {
        if (active) setStatus(s);
      })
      .catch(() => {
        if (active) setStatus({ configured: false, model: "" });
      });
    return () => {
      active = false;
    };
  }, []);

  return <StatusContext.Provider value={status}>{children}</StatusContext.Provider>;
}
