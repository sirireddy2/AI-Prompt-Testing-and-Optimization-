// Reusable UI primitives and small helpers shared across pages.
import React from "react";

/** Clamp a score-like value into 0..100. */
export function clampScore(v) {
  const n = Number(v);
  if (Number.isNaN(n)) return 0;
  return Math.max(0, Math.min(100, n));
}

/** Format a score for display: integers show without decimals, "-" if unknown. */
export function formatScore(v) {
  const n = Number(v);
  if (Number.isNaN(n) || v === null || v === undefined) return "—";
  return Number.isInteger(n) ? String(n) : n.toFixed(1);
}

/** Map a score to a tone class used by score pills, chips, etc. */
export function scoreTone(v) {
  const n = Number(v);
  if (v === null || v === undefined || Number.isNaN(n)) return "tone-muted";
  if (n >= 80) return "tone-green";
  if (n >= 60) return "tone-blue";
  if (n >= 40) return "tone-amber";
  return "tone-red";
}

/** Colour for a score (used in SVG rings and progress bars). */
export function scoreColor(v) {
  const n = clampScore(v);
  if (n >= 80) return "#16a34a";
  if (n >= 60) return "#2563eb";
  if (n >= 40) return "#d97706";
  return "#dc2626";
}

export function Card({ children, className = "", ...props }) {
  return (
    <div className={`card ${className}`} {...props}>
      {children}
    </div>
  );
}

export function Button({
  children,
  variant = "primary",
  loading = false,
  disabled,
  className = "",
  ...props
}) {
  return (
    <button
      className={`btn btn-${variant} ${className}`}
      disabled={disabled || loading}
      {...props}
    >
      {loading && <span className="spinner spinner-sm" />}
      {children}
    </button>
  );
}

export function Spinner({ label }) {
  return (
    <div className="loading-block">
      <div className="spinner" />
      {label && <p className="muted">{label}</p>}
    </div>
  );
}

export function EmptyState({ icon = "✨", title, message, action }) {
  return (
    <div className="empty-state">
      <div className="empty-icon">{icon}</div>
      <h3>{title}</h3>
      {message && <p className="muted">{message}</p>}
      {action}
    </div>
  );
}

export function Badge({ children, tone = "neutral" }) {
  return <span className={`badge badge-${tone}`}>{children}</span>;
}

export function Field({ label, hint, children }) {
  return (
    <div className="field">
      <div className="field-top">
        <label>{label}</label>
        {hint && <span className="field-hint muted">{hint}</span>}
      </div>
      {children}
    </div>
  );
}

export function StatCard({ label, value, suffix, icon, tone = "blue" }) {
  return (
    <Card className={`stat-card stat-${tone}`}>
      <div className="stat-icon">{icon}</div>
      <div className="stat-body">
        <div className="stat-value">
          {value}
          {suffix && <span className="stat-suffix">{suffix}</span>}
        </div>
        <div className="stat-label muted">{label}</div>
      </div>
    </Card>
  );
}

const CRITERION_LABELS = {
  relevance: "Relevance",
  clarity: "Clarity",
  completeness: "Completeness",
  instruction: "Instruction following",
  format: "Format consistency",
};

/** Per-criterion progress bars. `highlight` is a list of keys to mark as improved. */
export function ScoreBreakdown({ scores, highlight = [] }) {
  if (!scores) return null;
  const items = Object.entries(scores).filter(([k]) => k in CRITERION_LABELS);
  return (
    <div className="score-breakdown">
      {items.map(([k, v]) => {
        const improved = highlight.includes(k);
        return (
          <div className={`score-row${improved ? " improved" : ""}`} key={k}>
            <div className="score-row-top">
              <span>
                {CRITERION_LABELS[k]}
                {improved && <span className="improved-tag"> improved</span>}
              </span>
              <strong>{formatScore(v)}</strong>
            </div>
            <div className="score-bar-track">
              <div
                className="score-bar-fill"
                style={{ width: `${clampScore(v)}%`, background: scoreColor(v) }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}

/** Circular score gauge. */
export function ScoreCircle({ score, size = 120, label = "Overall" }) {
  const v = clampScore(score);
  const stroke = 8;
  const r = size / 2 - stroke;
  const c = 2 * Math.PI * r;
  const offset = c - (v / 100) * c;
  return (
    <div className="score-circle" style={{ width: size, height: size }}>
      <svg width={size} height={size}>
        <circle cx={size / 2} cy={size / 2} r={r} stroke="#e6ecf5" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={scoreColor(v)}
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
        />
      </svg>
      <div className="score-circle-label">
        <strong>{formatScore(score)}</strong>
        <span className="muted">{label}</span>
      </div>
    </div>
  );
}
