import { NavLink } from "react-router-dom";
import { useStatus } from "../context/StatusContext";

// Inline SVG icons keep the bundle dependency-free.
const Icons = {
  dashboard: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="3" y="3" width="7" height="9" rx="1.5" />
      <rect x="14" y="3" width="7" height="5" rx="1.5" />
      <rect x="14" y="12" width="7" height="9" rx="1.5" />
      <rect x="3" y="16" width="7" height="5" rx="1.5" />
    </svg>
  ),
  testing: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M9 2h6M9 2v6L4 18a3 3 0 0 0 3 4h10a3 3 0 0 0 3-4L15 8V2" />
      <path d="M7 14h10" />
    </svg>
  ),
  optimization: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M13 2 4 14h7l-1 8 9-12h-7l1-8z" />
    </svg>
  ),
  comparison: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M12 3v18" />
      <path d="M5 7H3v10h2l5 3V4L5 7z" />
      <path d="M16 9a3 3 0 0 1 0 6" />
      <path d="M19 6a7 7 0 0 1 0 12" />
    </svg>
  ),
  history: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M3 12a9 9 0 1 0 3-6.7L3 8" />
      <path d="M3 3v5h5" />
      <path d="M12 7v5l4 2" />
    </svg>
  ),
};

const LINKS = [
  { to: "/", label: "Dashboard", icon: Icons.dashboard },
  { to: "/testing", label: "Prompt Testing", icon: Icons.testing },
  { to: "/optimization", label: "Optimization", icon: Icons.optimization },
  { to: "/comparison", label: "Comparison", icon: Icons.comparison },
  { to: "/history", label: "History", icon: Icons.history },
];

export function Sidebar() {
  const status = useStatus();
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-mark">PP</div>
        <div className="brand-text">
          <div className="brand-name">PromptPilot</div>
          <div className="brand-sub muted">AI Prompt Tool</div>
        </div>
      </div>

      <nav className="nav">
        {LINKS.map((l) => (
          <NavLink
            key={l.to}
            to={l.to}
            end={l.to === "/"}
            className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}
          >
            <span className="nav-icon">{l.icon}</span>
            <span>{l.label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="sidebar-footer">
        <div className={`status-pill ${status.configured ? "ok" : "warn"}`}>
          <span className="dot" />
          {status.configured === null
            ? "Checking Gemini…"
            : status.configured
            ? "Gemini connected"
            : "Gemini not configured"}
        </div>
        <p className="muted small">Test, score &amp; optimize prompts with Gemini.</p>
      </div>
    </aside>
  );
}
