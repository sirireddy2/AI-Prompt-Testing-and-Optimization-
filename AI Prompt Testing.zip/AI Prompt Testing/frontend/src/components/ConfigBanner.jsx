import { useStatus } from "../context/StatusContext";

// Shows a clear banner when no Gemini API key is configured, instead of
// letting the app crash when the user clicks Test / Optimize.
export function ConfigBanner() {
  const status = useStatus();
  if (status.configured !== false) return null; // null = loading, true = ok
  return (
    <div className="config-banner">
      <strong>Gemini API key not configured.</strong>
      <span>
        Create <code>backend/.env</code> with <code>GEMINI_API_KEY=your_key</code> and
        restart the backend server to enable AI testing and optimization.
      </span>
    </div>
  );
}
