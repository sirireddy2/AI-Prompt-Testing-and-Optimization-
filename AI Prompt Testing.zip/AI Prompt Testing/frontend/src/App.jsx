import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { Sidebar } from "./components/Sidebar";
import { ConfigBanner } from "./components/ConfigBanner";
import { ToastProvider } from "./components/Toast";
import { StatusProvider } from "./context/StatusContext";
import Dashboard from "./pages/Dashboard";
import Testing from "./pages/Testing";
import Optimization from "./pages/Optimization";
import Comparison from "./pages/Comparison";
import History from "./pages/History";

export default function App() {
  return (
    <StatusProvider>
      <ToastProvider>
        <BrowserRouter>
          <div className="app-shell">
            <Sidebar />
            <main className="app-main">
              <ConfigBanner />
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/testing" element={<Testing />} />
                <Route path="/optimization" element={<Optimization />} />
                <Route path="/comparison" element={<Comparison />} />
                <Route path="/history" element={<History />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </main>
          </div>
        </BrowserRouter>
      </ToastProvider>
    </StatusProvider>
  );
}
