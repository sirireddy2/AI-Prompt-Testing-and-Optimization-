// Small fetch wrapper for the PromptPilot backend.
//
// The API base URL can be overridden with VITE_API_URL in frontend/.env,
// otherwise it defaults to the local FastAPI server on port 8000.

const API_BASE =
  (import.meta.env && import.meta.env.VITE_API_URL) || "http://localhost:8000/api";

/**
 * Make a JSON request to the backend and return parsed data.
 * Throws an Error with a human-readable message on failure.
 */
async function request(path, options = {}) {
  let res;
  try {
    res = await fetch(`${API_BASE}${path}`, {
      headers: { "Content-Type": "application/json" },
      ...options,
    });
  } catch (e) {
    throw new Error(
      "Cannot reach the PromptPilot backend. Make sure it is running on http://localhost:8000."
    );
  }

  const text = await res.text();
  let data = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = { detail: text };
    }
  }

  if (!res.ok) {
    const message =
      (data && (data.detail || data.message)) || `Request failed (${res.status}).`;
    throw new Error(message);
  }
  return data;
}

export const api = {
  status: () => request("/status"),

  testPrompt: (payload) =>
    request("/test-prompt", { method: "POST", body: JSON.stringify(payload) }),

  optimizePrompt: (payload) =>
    request("/optimize-prompt", { method: "POST", body: JSON.stringify(payload) }),

  comparePrompts: (payload) =>
    request("/compare-prompts", { method: "POST", body: JSON.stringify(payload) }),

  dashboard: () => request("/dashboard"),

  history: (params = {}) => {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== "") qs.append(k, v);
    });
    const s = qs.toString();
    return request(`/history${s ? "?" + s : ""}`);
  },

  historyDetail: (id) => request(`/history/${id}`),

  deleteHistory: (id) =>
    request(`/history/${id}`, { method: "DELETE" }),
};
