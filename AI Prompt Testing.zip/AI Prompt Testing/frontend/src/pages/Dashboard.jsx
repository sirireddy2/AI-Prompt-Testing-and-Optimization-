import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Bar,
  CartesianGrid,
  ComposedChart,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { api } from "../services/api";
import {
  Button,
  Card,
  EmptyState,
  Spinner,
  StatCard,
  formatScore,
  scoreTone,
} from "../components/ui";

export default function Dashboard() {
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    setLoading(true);
    api
      .dashboard()
      .then((d) => active && setData(d))
      .catch((e) => active && setError(e.message))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, []);

  return (
    <div className="page">
      <header className="page-head">
        <div>
          <h1>Dashboard</h1>
          <p className="muted">
            Overview of your prompt testing and optimization activity.
          </p>
        </div>
        <Button onClick={() => navigate("/testing")}>+ Quick Start Testing</Button>
      </header>

      {loading && <Spinner label="Loading dashboard…" />}
      {error && <div className="alert alert-error">{error}</div>}

      {!loading && data && (
        <>
          <div className="stat-grid">
            <StatCard
              label="Total prompts tested"
              value={data.total_prompts_tested}
              icon="🧪"
              tone="blue"
            />
            <StatCard
              label="Total prompts optimized"
              value={data.total_prompts_optimized}
              icon="⚡"
              tone="purple"
            />
            <StatCard
              label="Average quality score"
              value={formatScore(data.average_quality_score)}
              suffix="/100"
              icon="📈"
              tone="green"
            />
          </div>

          <div className="grid-2">
            <Card>
              <div className="card-head">
                <h3>Prompt testing history</h3>
                <span className="muted small">last 7 days</span>
              </div>
              {data.history_chart.length === 0 ? (
                <EmptyState
                  icon="📊"
                  title="No tests yet"
                  message="Tests you run will appear in this chart."
                  action={
                    <Button variant="ghost" onClick={() => navigate("/testing")}>
                      Run your first test
                    </Button>
                  }
                />
              ) : (
                <ResponsiveContainer width="100%" height={280}>
                  <ComposedChart data={data.history_chart} margin={{ top: 10, right: 10, left: -16, bottom: 0 }}>
                    <CartesianGrid stroke="#eef2f7" vertical={false} />
                    <XAxis
                      dataKey="label"
                      tickLine={false}
                      axisLine={false}
                      tick={{ fill: "#64748b", fontSize: 12 }}
                    />
                    <YAxis
                      yAxisId="left"
                      allowDecimals={false}
                      tickLine={false}
                      axisLine={false}
                      tick={{ fill: "#64748b", fontSize: 12 }}
                    />
                    <YAxis
                      yAxisId="right"
                      orientation="right"
                      domain={[0, 100]}
                      tickLine={false}
                      axisLine={false}
                      tick={{ fill: "#64748b", fontSize: 12 }}
                    />
                    <Tooltip
                      contentStyle={{
                        borderRadius: 10,
                        border: "1px solid #e6ecf5",
                        boxShadow: "0 8px 24px rgba(15,23,42,.1)",
                      }}
                    />
                    <Bar
                      yAxisId="left"
                      dataKey="count"
                      name="Tests"
                      fill="#2563eb"
                      radius={[6, 6, 0, 0]}
                      barSize={30}
                    />
                    <Line
                      yAxisId="right"
                      type="monotone"
                      dataKey="average_score"
                      name="Avg score"
                      stroke="#7c3aed"
                      strokeWidth={2.5}
                      dot={{ r: 3, fill: "#7c3aed" }}
                    />
                  </ComposedChart>
                </ResponsiveContainer>
              )}
            </Card>

            <Card>
              <div className="card-head">
                <h3>Recent activity</h3>
              </div>
              {data.recent_activity.length === 0 ? (
                <EmptyState
                  icon="🧭"
                  title="Nothing here yet"
                  message="Your most recent tests will show up here."
                />
              ) : (
                <ul className="activity-list">
                  {data.recent_activity.map((a) => (
                    <li
                      key={a.id}
                      className="activity-item"
                      onClick={() => navigate("/history")}
                    >
                      <div className="activity-main">
                        <p className="activity-prompt">{a.original_prompt || "(empty)"}</p>
                        <span className="muted small">
                          {new Date(a.created_at).toLocaleString()}
                        </span>
                      </div>
                      <div className="activity-right">
                        {a.has_optimized && <span className="badge badge-purple">optimized</span>}
                        <span className={`score-pill ${scoreTone(a.score)}`}>
                          {formatScore(a.score)}
                        </span>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          </div>
        </>
      )}
    </div>
  );
}
