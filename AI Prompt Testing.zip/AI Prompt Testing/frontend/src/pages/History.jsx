import { useCallback, useEffect, useState } from "react";
import { api } from "../services/api";
import { useToast } from "../components/Toast";
import {
  Button,
  Card,
  EmptyState,
  Spinner,
  formatScore,
  scoreTone,
} from "../components/ui";

function DetailBlock({ label, text, mono }) {
  return (
    <div className="detail-block">
      <div className="muted small detail-label">{label}</div>
      <pre className={mono ? "response-box" : "prompt-box"}>{text || "—"}</pre>
    </div>
  );
}

function DetailChips({ data }) {
  const rows = [
    ["Relevance", data.relevance_score],
    ["Clarity", data.clarity_score],
    ["Completeness", data.completeness_score],
    ["Instruction", data.instruction_score],
    ["Format", data.format_score],
  ];
  return (
    <div className="score-chips">
      {rows.map(([k, v]) => (
        <span key={k} className={`chip ${scoreTone(v)}`}>
          {k}: {formatScore(v)}
        </span>
      ))}
    </div>
  );
}

export default function History() {
  const toast = useToast();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const [minScore, setMinScore] = useState("");
  const [hasOptimized, setHasOptimized] = useState("any");
  const [sort, setSort] = useState("newest");

  const [detailId, setDetailId] = useState(null);
  const [detail, setDetail] = useState(null);
  const [detailLoading, setDetailLoading] = useState(false);

  // Debounce the search box.
  useEffect(() => {
    const t = setTimeout(() => setDebounced(query), 350);
    return () => clearTimeout(t);
  }, [query]);

  const load = useCallback(() => {
    setLoading(true);
    setError("");
    api
      .history({
        q: debounced || undefined,
        min_score: minScore || undefined,
        has_optimized: hasOptimized === "any" ? undefined : hasOptimized === "yes",
        sort,
      })
      .then((res) => setItems(res.items || []))
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [debounced, minScore, hasOptimized, sort]);

  useEffect(load, [load]);

  const openDetail = async (id) => {
    setDetailId(id);
    setDetail(null);
    setDetailLoading(true);
    try {
      const d = await api.historyDetail(id);
      setDetail(d);
    } catch (e) {
      toast.error(e.message);
      setDetailId(null);
    } finally {
      setDetailLoading(false);
    }
  };

  const remove = async (id) => {
    if (!window.confirm("Delete this test and its optimization records? This cannot be undone.")) {
      return;
    }
    try {
      await api.deleteHistory(id);
      toast.success("History item deleted.");
      if (detailId === id) setDetailId(null);
      load();
    } catch (e) {
      toast.error(e.message);
    }
  };

  const hasItems = items.length > 0;
  const noFilters = !debounced && !minScore && hasOptimized === "any";

  return (
    <div className="page">
      <header className="page-head">
        <div>
          <h1>Testing History</h1>
          <p className="muted">All prompts you have tested and optimized, saved in SQLite.</p>
        </div>
      </header>

      <Card className="filters">
        <div className="filter-row">
          <input
            className="input"
            placeholder="Search prompts…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <select className="input" value={minScore} onChange={(e) => setMinScore(e.target.value)}>
            <option value="">Any score</option>
            <option value="80">80+</option>
            <option value="60">60+</option>
            <option value="40">40+</option>
          </select>
          <select className="input" value={hasOptimized} onChange={(e) => setHasOptimized(e.target.value)}>
            <option value="any">All</option>
            <option value="yes">Optimized only</option>
            <option value="no">Not optimized</option>
          </select>
          <select className="input" value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="newest">Newest first</option>
            <option value="oldest">Oldest first</option>
            <option value="score_desc">Highest score</option>
            <option value="score_asc">Lowest score</option>
          </select>
        </div>
      </Card>

      {loading && <Spinner label="Loading history…" />}
      {error && <div className="alert alert-error">{error}</div>}
      {!loading && !error && !hasItems && (
        <Card>
          <EmptyState
            icon="🗂️"
            title="No history found"
            message={noFilters ? "Run a test to start building your history." : "No tests match your filters."}
          />
        </Card>
      )}

      {!loading && hasItems && (
        <div className="history-list">
          {items.map((it) => (
            <Card key={it.id} className="history-item">
              <div className="history-main">
                <div className="history-prompt">{it.original_prompt}</div>
                <div className="history-meta muted small">
                  <span>Test #{it.id}</span>
                  <span>·</span>
                  <span>{new Date(it.created_at).toLocaleString()}</span>
                  {it.optimized && (
                    <>
                      <span>·</span>
                      <span className="badge badge-purple">optimized</span>
                    </>
                  )}
                </div>
                {it.optimized && (
                  <div className="history-opt muted small">
                    Optimized → {it.optimized.optimized_prompt}
                  </div>
                )}
              </div>
              <div className="history-side">
                <div className={`score-pill ${scoreTone(it.original_score)}`}>
                  {formatScore(it.original_score)}
                </div>
                <div className="history-actions">
                  <Button variant="ghost" onClick={() => openDetail(it.id)}>
                    View details
                  </Button>
                  <Button variant="danger-ghost" onClick={() => remove(it.id)}>
                    Delete
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {detailId && (
        <div className="modal-backdrop" onClick={() => setDetailId(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-head">
              <h3>Test details</h3>
              <button className="modal-close" onClick={() => setDetailId(null)} aria-label="Close">
                ×
              </button>
            </div>
            {detailLoading && <Spinner label="Loading details…" />}
            {!detailLoading && detail && (
              <div className="modal-body">
                <DetailBlock label="Original prompt" text={detail.original_prompt} />
                {detail.test_input ? <DetailBlock label="Test input" text={detail.test_input} /> : null}
                <DetailBlock label="AI response" text={detail.original_response} mono />
                <div className="detail-scores">
                  <div className={`score-pill ${scoreTone(detail.original_score)}`}>
                    Overall {formatScore(detail.original_score)}/100
                  </div>
                  <DetailChips data={detail} />
                </div>

                {detail.optimized && detail.optimized.length > 0 ? (
                  <>
                    <h4 className="detail-sub">Optimization</h4>
                    <DetailBlock label="Optimized prompt" text={detail.optimized[0].optimized_prompt} />
                    {detail.optimized[0].optimization_explanation && (
                      <DetailBlock
                        label="Explanation"
                        text={detail.optimized[0].optimization_explanation}
                      />
                    )}
                    {detail.optimized[0].optimized_response && (
                      <DetailBlock
                        label="Optimized response"
                        text={detail.optimized[0].optimized_response}
                        mono
                      />
                    )}
                    {detail.optimized[0].optimized_score != null && (
                      <div className={`score-pill ${scoreTone(detail.optimized[0].optimized_score)}`}>
                        Optimized score {formatScore(detail.optimized[0].optimized_score)}/100
                      </div>
                    )}
                  </>
                ) : (
                  <p className="muted small">No optimization saved for this test.</p>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
