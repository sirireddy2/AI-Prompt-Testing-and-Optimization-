import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { api } from "../services/api";
import { useToast } from "../components/Toast";
import {
  Button,
  Card,
  EmptyState,
  Field,
  ScoreBreakdown,
  Spinner,
  formatScore,
  scoreTone,
} from "../components/ui";

function round1(n) {
  return Math.round((Number(n) || 0) * 10) / 10;
}

export default function Optimization() {
  const location = useLocation();
  const navigate = useNavigate();
  const toast = useToast();

  const prefill = location.state || {};
  const [originalPrompt, setOriginalPrompt] = useState(prefill.original_prompt || "");
  const [testInput, setTestInput] = useState(prefill.test_input || "");
  const [testId, setTestId] = useState(prefill.test_id || null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const s = location.state || {};
    if (s.original_prompt !== undefined) setOriginalPrompt(s.original_prompt || "");
    if (s.test_input !== undefined) setTestInput(s.test_input || "");
    setTestId(s.test_id || null);
  }, [location.state]);

  const optimize = async () => {
    if (!originalPrompt.trim()) {
      setError("Please enter a prompt to optimize.");
      return;
    }
    setLoading(true);
    setError("");
    setResult(null);
    try {
      const res = await api.optimizePrompt({
        original_prompt: originalPrompt,
        test_input: testInput,
        test_id: testId,
      });
      setResult(res);
      setTestId(res.test_id);
      toast.success("Prompt optimized and saved.");
    } catch (e) {
      setError(e.message);
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(result.optimized_prompt);
      setCopied(true);
      toast.success("Optimized prompt copied to clipboard.");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Could not copy. Please select the text and copy manually.");
    }
  };

  const diff = result ? round1(result.optimized_score - result.original_score) : 0;

  return (
    <div className="page">
      <header className="page-head">
        <div>
          <h1>Prompt Optimization</h1>
          <p className="muted">Let Gemini rewrite your prompt and explain what it improved.</p>
        </div>
      </header>

      <div className="grid-2">
        <Card>
          <div className="card-head">
            <h3>Your prompt</h3>
          </div>
          <Field label="Original prompt">
            <textarea
              className="input area"
              rows={6}
              value={originalPrompt}
              onChange={(e) => setOriginalPrompt(e.target.value)}
              placeholder="Paste the prompt you want to improve."
            />
          </Field>
          <Field label="Test input (optional)">
            <textarea
              className="input area"
              rows={4}
              value={testInput}
              onChange={(e) => setTestInput(e.target.value)}
              placeholder="The input the prompt is applied to, if any."
            />
          </Field>
          <div className="actions">
            <Button onClick={optimize} loading={loading} disabled={loading}>
              Optimize Prompt
            </Button>
          </div>
          {error && <div className="alert alert-error">{error}</div>}
        </Card>

        <Card>
          <div className="card-head">
            <h3>Optimized result</h3>
          </div>
          {loading && <Spinner label="Analyzing, rewriting and testing the prompt…" />}
          {!loading && !result && (
            <EmptyState
              icon="⚡"
              title="No optimization yet"
              message="Enter a prompt and click Optimize Prompt to get an improved version with an explanation."
            />
          )}
          {!loading && result && (
            <div className="result">
              <div className="opt-score-row">
                <div className="mini-score">
                  <span className="muted small">Original</span>
                  <strong className={scoreTone(result.original_score)}>
                    {formatScore(result.original_score)}
                  </strong>
                </div>
                <div className="opt-arrow">→</div>
                <div className="mini-score">
                  <span className="muted small">Optimized</span>
                  <strong className={scoreTone(result.optimized_score)}>
                    {formatScore(result.optimized_score)}
                  </strong>
                </div>
                <div className={`diff-pill ${diff >= 0 ? "pos" : "neg"}`}>
                  {diff >= 0 ? "+" : ""}
                  {formatScore(diff)}
                </div>
              </div>

              <div className="result-block">
                <h4>Optimized prompt</h4>
                <pre className="prompt-box">{result.optimized_prompt}</pre>
                <Button variant="ghost" className="copy-btn" onClick={copy}>
                  {copied ? "Copied ✓" : "Copy optimized prompt"}
                </Button>
              </div>

              <div className="result-block">
                <h4>What changed</h4>
                <p className="muted">{result.explanation}</p>
              </div>

              <div className="result-block">
                <h4>Optimized response preview</h4>
                <pre className="response-box">{result.optimized_response}</pre>
              </div>

              <ScoreBreakdown scores={result.optimized_scores} />

              <div className="actions">
                <Button
                  onClick={() =>
                    navigate("/comparison", {
                      state: {
                        original_prompt: result.original_prompt,
                        optimized_prompt: result.optimized_prompt,
                        test_input: testInput,
                        original_test_id: result.test_id,
                        optimized_id: result.optimized_id,
                      },
                    })
                  }
                >
                  Test &amp; Compare
                </Button>
                <Button
                  variant="ghost"
                  onClick={() =>
                    navigate("/testing", {
                      state: { original_prompt: result.optimized_prompt, test_input: testInput },
                    })
                  }
                >
                  Open in Testing Lab
                </Button>
              </div>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
