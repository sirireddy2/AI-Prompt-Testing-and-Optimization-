import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { api } from "../services/api";
import { useToast } from "../components/Toast";
import {
  Button,
  Card,
  EmptyState,
  ScoreBreakdown,
  ScoreCircle,
  Spinner,
  formatScore,
} from "../components/ui";

const LS_KEY = "promptpilot:lastCompare";

function CompareColumn({ title, tone, prompt, response, score, scores, highlight = [] }) {
  return (
    <Card className={`compare-col ${tone}`}>
      <div className="card-head">
        <h3>{title}</h3>
        <span className="muted small">Score {formatScore(score)}/100</span>
      </div>
      <div className="result-score">
        <ScoreCircle score={score} size={110} />
      </div>
      <div className="result-block">
        <h4>Prompt</h4>
        <pre className="prompt-box">{prompt}</pre>
      </div>
      <div className="result-block">
        <h4>AI response</h4>
        <pre className="response-box">{response}</pre>
      </div>
      <ScoreBreakdown scores={scores} highlight={highlight} />
    </Card>
  );
}

export default function Comparison() {
  const location = useLocation();
  const navigate = useNavigate();
  const toast = useToast();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let payload = location.state;
    if (!payload) {
      try {
        payload = JSON.parse(localStorage.getItem(LS_KEY) || "null");
      } catch {
        payload = null;
      }
    }
    if (!payload || !payload.original_prompt || !payload.optimized_prompt) {
      setLoading(false);
      return;
    }
    // Persist so a page refresh does not lose the comparison.
    localStorage.setItem(LS_KEY, JSON.stringify(payload));

    setLoading(true);
    setError("");
    api
      .comparePrompts({
        original_prompt: payload.original_prompt,
        optimized_prompt: payload.optimized_prompt,
        test_input: payload.test_input || "",
        model: payload.model || null,
        original_test_id: payload.original_test_id || null,
        optimized_id: payload.optimized_id || null,
      })
      .then((res) => setData(res))
      .catch((e) => {
        setError(e.message);
        toast.error(e.message);
      })
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (loading) {
    return (
      <div className="page">
        <header className="page-head">
          <div>
            <h1>Comparison</h1>
            <p className="muted">Side-by-side of your original and optimized prompts.</p>
          </div>
        </header>
        <Card>
          <Spinner label="Generating and comparing both prompts…" />
        </Card>
      </div>
    );
  }

  if (!data && !error) {
    return (
      <div className="page">
        <header className="page-head">
          <div>
            <h1>Comparison</h1>
            <p className="muted">Side-by-side of your original and optimized prompts.</p>
          </div>
        </header>
        <Card>
          <EmptyState
            icon="🔄"
            title="Nothing to compare yet"
            message="Optimize a prompt first, then compare it against the original to see the score difference."
            action={<Button onClick={() => navigate("/optimization")}>Go to Optimization</Button>}
          />
        </Card>
      </div>
    );
  }

  const orig = data?.original;
  const opt = data?.optimized;
  const diff = data?.score_difference ?? 0;
  const improvedCriteria =
    orig && opt
      ? Object.entries(opt.scores)
          .filter(([k, v]) => (v || 0) > (orig.scores[k] || 0))
          .map(([k]) => k)
      : [];

  return (
    <div className="page">
      <header className="page-head">
        <div>
          <h1>Comparison</h1>
          <p className="muted">Side-by-side of your original and optimized prompts.</p>
        </div>
      </header>

      {error && <div className="alert alert-error">{error}</div>}

      {data && (
        <>
          <Card className="compare-summary">
            <div className="summary-left">
              <span className="muted small">Score difference</span>
              <div className={`diff-big ${diff >= 0 ? "pos" : "neg"}`}>
                {diff >= 0 ? "+" : ""}
                {formatScore(diff)} pts
              </div>
            </div>
            <div className="summary-right">
              <strong>Summary</strong>
              <p className="muted">{data.improvement_summary}</p>
            </div>
          </Card>

          <div className="compare-grid">
            <CompareColumn
              title="Original"
              tone="muted-tone"
              prompt={orig.prompt}
              response={orig.response}
              score={orig.overall_score}
              scores={orig.scores}
            />
            <CompareColumn
              title="Optimized"
              tone="accent-tone"
              prompt={opt.prompt}
              response={opt.response}
              score={opt.overall_score}
              scores={opt.scores}
              highlight={improvedCriteria}
            />
          </div>
        </>
      )}
    </div>
  );
}
