import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { api } from "../services/api";
import { useToast } from "../components/Toast";
import {
  Button,
  Card,
  EmptyState,
  Field,
  ScoreBreakdown,
  ScoreCircle,
  Spinner,
} from "../components/ui";

const MODELS = [
  { value: "", label: "Server default" },
  { value: "gemini-1.5-flash", label: "gemini-1.5-flash" },
  { value: "gemini-2.0-flash", label: "gemini-2.0-flash" },
  { value: "gemini-2.5-flash", label: "gemini-2.5-flash" },
  { value: "gemini-1.5-pro", label: "gemini-1.5-pro" },
];

export default function Testing() {
  const location = useLocation();
  const navigate = useNavigate();
  const toast = useToast();

  const prefill = location.state || {};
  const [originalPrompt, setOriginalPrompt] = useState(prefill.original_prompt || "");
  const [testInput, setTestInput] = useState(prefill.test_input || "");
  const [model, setModel] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  // Re-prefill when the user arrives from another page carrying state.
  useEffect(() => {
    const s = location.state || {};
    if (s.original_prompt !== undefined) setOriginalPrompt(s.original_prompt || "");
    if (s.test_input !== undefined) setTestInput(s.test_input || "");
  }, [location.state]);

  const runTest = async () => {
    if (!originalPrompt.trim()) {
      setError("Please enter a prompt to test.");
      return;
    }
    setLoading(true);
    setError("");
    setResult(null);
    try {
      const res = await api.testPrompt({
        original_prompt: originalPrompt,
        test_input: testInput,
        model: model || null,
      });
      setResult(res);
      toast.success("Prompt tested and saved to history.");
    } catch (e) {
      setError(e.message);
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page">
      <header className="page-head">
        <div>
          <h1>Prompt Testing</h1>
          <p className="muted">
            Run a prompt and see the AI response plus an estimated quality score.
          </p>
        </div>
      </header>

      <div className="grid-2">
        <Card>
          <div className="card-head">
            <h3>Test a prompt</h3>
          </div>
          <Field label="Original prompt" hint="The instructions you want to evaluate.">
            <textarea
              className="input area"
              rows={6}
              value={originalPrompt}
              onChange={(e) => setOriginalPrompt(e.target.value)}
              placeholder="e.g. Summarize the following article in exactly 3 bullet points, under 20 words each."
            />
          </Field>
          <Field label="Test input" hint="Optional. The data the prompt should operate on.">
            <textarea
              className="input area"
              rows={5}
              value={testInput}
              onChange={(e) => setTestInput(e.target.value)}
              placeholder="e.g. Paste an article, a question, or sample data here."
            />
          </Field>
          <Field label="AI model" hint="Leave on server default unless you need a specific model.">
            <select className="input" value={model} onChange={(e) => setModel(e.target.value)}>
              {MODELS.map((m) => (
                <option key={m.value} value={m.value}>
                  {m.label}
                </option>
              ))}
            </select>
          </Field>

          <div className="actions">
            <Button onClick={runTest} loading={loading} disabled={loading}>
              Test Prompt
            </Button>
            {result && (
              <Button
                variant="ghost"
                onClick={() =>
                  navigate("/optimization", {
                    state: {
                      original_prompt: originalPrompt,
                      test_input: testInput,
                      test_id: result.id,
                    },
                  })
                }
              >
                Optimize this prompt
              </Button>
            )}
          </div>
          {error && <div className="alert alert-error">{error}</div>}
        </Card>

        <Card>
          <div className="card-head">
            <h3>Result</h3>
            {result && <span className="muted small">Test #{result.id}</span>}
          </div>
          {loading && <Spinner label="Generating and evaluating the response…" />}
          {!loading && !result && (
            <EmptyState
              icon="🧪"
              title="No result yet"
              message="Enter a prompt and click Test Prompt to see the AI response and quality score."
            />
          )}
          {!loading && result && (
            <div className="result">
              <div className="result-score">
                <ScoreCircle score={result.overall_score} />
                <div className="result-score-note muted small">
                  Estimated quality score (0–100). Not a guarantee of correctness.
                </div>
              </div>
              <ScoreBreakdown scores={result.scores} />
              <div className="result-block">
                <h4>AI response</h4>
                <pre className="response-box">{result.response}</pre>
              </div>
              {result.reasoning && (
                <div className="result-block">
                  <h4>Evaluator notes</h4>
                  <p className="muted">{result.reasoning}</p>
                </div>
              )}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
