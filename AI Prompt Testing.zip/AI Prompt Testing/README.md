# PromptPilot – AI Prompt Testing & Optimization Tool

PromptPilot helps you **test** AI prompts, **score** the responses, **optimize**
the prompts automatically with Google Gemini, and **compare** the original
versus the improved version. Everything is saved in a SQLite database that is
created automatically.

Built with **React + Vite** on the frontend and **FastAPI + SQLAlchemy + Gemini**
on the backend.

---

## 1. Features

- **Dashboard** – totals (tested, optimized), average quality score, a 7-day
  testing history chart, and recent activity. All numbers come from the database.
- **Prompt Testing** – run a prompt against optional test input, get the AI
  response and an estimated quality score (0–100) broken down by relevance,
  clarity, completeness, instruction following and format consistency.
- **Prompt Optimization** – Gemini rewrites your prompt and explains the changes.
  Copy the result or send it to the Comparison / Testing pages.
- **Prompt Comparison** – side-by-side original vs. optimized: prompts, responses,
  scores, per-criterion breakdown and the score difference.
- **Testing History** – every saved test with search, score filter, "optimized
  only" filter, sort, a details modal and delete. Records survive restarts.

The quality scores are **estimated** by an AI evaluator, not verified truth.

---

## 2. Project structure

```
PromptPilot/
├── backend/
│   ├── app/
│   │   ├── main.py                # FastAPI app, CORS, auto-create DB on startup
│   │   ├── config.py              # loads GEMINI_API_KEY / GEMINI_MODEL from .env
│   │   ├── database.py            # SQLAlchemy engine, session, init_db()
│   │   ├── models.py              # prompt_tests + optimized_prompts tables
│   │   ├── schemas.py             # Pydantic request validation
│   │   ├── routes/
│   │   │   ├── testing.py          # POST /api/test-prompt
│   │   │   ├── optimization.py    # POST /api/optimize-prompt, /api/compare-prompts
│   │   │   ├── history.py         # GET /api/history, GET/DELETE /api/history/{id}
│   │   │   └── dashboard.py      # GET /api/dashboard
│   │   └── services/
│   │       ├── gemini_service.py     # all Gemini SDK calls
│   │       ├── evaluation_service.py # parse eval JSON -> scores
│   │       └── optimization_service.py
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── components/  (Sidebar, Toast, ConfigBanner, ui.jsx)
│   │   ├── context/     (StatusContext)
│   │   ├── pages/       (Dashboard, Testing, Optimization, Comparison, History)
│   │   ├── services/    (api.js)
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── index.css
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
├── README.md
└── .gitignore
```

---

## 3. Setup (Windows / PowerShell)

### 3.1 Configure your Gemini API key

Get a free key from <https://aistudio.google.com/app/apikey>, then:

```powershell
cd "c:\Users\siri\Downloads\AI Prompt Testing\backend"
Copy-Item .env.example .env
notepad .env
```

Set the key and (optionally) the model, for example:

```
GEMINI_API_KEY=AIza...
GEMINI_MODEL=gemini-1.5-flash
```

If the key is missing the app still runs, but shows a clear configuration banner
instead of crashing.

### 3.2 Install dependencies

Backend:

```powershell
cd "c:\Users\siri\Downloads\AI Prompt Testing\backend"
python -m pip install -r requirements.txt
```

Frontend:

```powershell
cd "c:\Users\siri\Downloads\AI Prompt Testing\frontend"
npm install
```

---

## 4. Run the project

Open **two** PowerShell terminals.

Terminal 1 – backend (creates `backend/promptpilot.db` automatically on first start):

```powershell
cd "c:\Users\siri\Downloads\AI Prompt Testing\backend"
python -m uvicorn app.main:app --reload --port 8000
```

Terminal 2 – frontend:

```powershell
cd "c:\Users\siri\Downloads\AI Prompt Testing\frontend"
npm run dev
```

Then open <http://localhost:8000/docs> to see the API docs, and
<http://localhost:5173> for the app.

---

## 5. API endpoints

| Method | Path | Description |
| ------ | ---- | ----------- |
| GET | `/api/status` | Whether Gemini is configured + model name |
| POST | `/api/test-prompt` | Run + evaluate a prompt, save it |
| POST | `/api/optimize-prompt` | Rewrite a prompt, run + evaluate the new version |
| POST | `/api/compare-prompts` | Generate + evaluate both prompts, return a comparison |
| GET | `/api/dashboard` | Aggregated statistics from the database |
| GET | `/api/history` | List tests (search, score filter, optimized filter, sort) |
| GET | `/api/history/{id}` | Full detail of one test |
| DELETE | `/api/history/{id}` | Delete a test (cascades to its optimizations) |

---

## 6. Database

SQLite file `backend/promptpilot.db`, created automatically on startup.

- `prompt_tests` – original prompt, test input, response, overall + 5 criterion scores, timestamp.
- `optimized_prompts` – linked to a test via `test_id` (foreign key, cascade delete),
  optimized prompt, explanation, response, overall + 5 criterion scores, timestamp.

Records are not lost on restart.

---

## 7. How to test each feature (step by step)

1. **Dashboard** – open the app; with no data it shows zeros and empty states.
2. **Prompt Testing** – go to *Prompt Testing*. Enter a prompt (e.g.
   "Summarize the text in 3 bullet points"), paste a test input, click **Test Prompt**.
   You get the AI response, an overall ring score and the 5 criterion bars.
3. **Prompt Optimization** – click **Optimize this prompt** (or open *Optimization*).
   Click **Optimize Prompt**. You get a rewritten prompt, the changes explanation,
   a response preview, the original vs. optimized score, and **Copy**.
4. **Prompt Comparison** – from Optimization click **Test & Compare**. You see
   both prompts, responses, scores, the score difference and which criteria
   improved.
5. **Testing History** – go to *History*. Use the search box, score filter and
   "Optimized only" filter. Click **View details** for the modal, **Delete** to remove.
6. **Dashboard again** – numbers and the chart now reflect your tests.
